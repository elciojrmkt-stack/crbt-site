# CRBT – Site de Inscrições (pronto)

Este projeto já está pronto para:
- 6 categorias
- inscrição por dupla
- LetzPlay obrigatório
- código da federação opcional
- 16 duplas por categoria (bloqueio automático via contagem de aprovados)
- pagamento Mercado Pago (Pix/Cartão)
- planilha Google Sheets (grátis) como painel

## IMPORTANTE (segurança)
NUNCA cole seu Access Token em mensagens públicas. Use variáveis de ambiente.
Se você já compartilhou um token, gere outro no Mercado Pago (rotacionar) e use o novo.

---

## Passo A — Criar a Planilha (Google Sheets)
1) Crie uma planilha chamada **CRBT Inscrições**
2) Abra **Extensões → Apps Script**
3) Cole o conteúdo de `google-apps-script/Code.gs`
4) Clique em **Implantar → Nova implantação**
   - Tipo: **Aplicativo da Web**
   - Quem tem acesso: **Qualquer pessoa**
5) Copie a **URL** gerada (ela será a `SHEETS_WEBAPP_URL`)

---

## Passo B — Publicar o site (Vercel – o mais fácil e barato)
1) Crie conta na Vercel (Google)
2) Clique em **Add New → Project**
3) Em **Import**, escolha **"Upload"** e envie este projeto (zip) OU suba para o GitHub e importe
4) Antes de concluir, vá em **Environment Variables** e crie:
   - `MP_ACCESS_TOKEN` = seu token de PRODUÇÃO (Mercado Pago)
   - `SHEETS_WEBAPP_URL` = URL do Apps Script
   - `BASE_URL` = https://crbt.com.br (quando o domínio estiver apontado)

5) Conclua o deploy.

---

## Passo C — Apontar domínio crbt.com.br
Na Vercel:
- Vá em **Settings → Domains**
- Adicione `crbt.com.br`
Ela vai te mostrar quais registros DNS criar no seu provedor do domínio (A/CNAME).

---

## Rodar no seu computador (opcional)
```bash
npm install
npm run dev
```

Abra: http://localhost:3000
