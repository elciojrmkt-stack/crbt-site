import { TeamPayload } from "./validation";

const SHEETS_WEBAPP_URL = process.env.SHEETS_WEBAPP_URL!;

export async function sheetsCreatePending(input: {
  category: string;
  payload: TeamPayload;
  externalReference: string;
}) {
  if (!SHEETS_WEBAPP_URL) return;

  await fetch(SHEETS_WEBAPP_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "create_pending", ...input }),
    cache: "no-store",
  });
}

export async function sheetsUpdateStatus(input: {
  externalReference: string;
  status: "approved" | "pending" | "rejected" | "cancelled";
  paymentId?: string;
}) {
  if (!SHEETS_WEBAPP_URL) return;

  await fetch(SHEETS_WEBAPP_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "update_status", ...input }),
    cache: "no-store",
  });
}

export async function sheetsCountApprovedByCategory(category: string): Promise<number> {
  if (!SHEETS_WEBAPP_URL) return 0;

  const res = await fetch(SHEETS_WEBAPP_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "count_approved", category }),
    cache: "no-store",
  });

  const json = await res.json().catch(() => ({}));
  return Number((json as any)?.count ?? 0);
}
