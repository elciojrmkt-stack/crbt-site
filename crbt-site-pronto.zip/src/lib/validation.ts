import { z } from "zod";

export const AthleteSchema = z.object({
  nome: z.string().min(3, "Informe o nome completo."),
  whatsapp: z.string().min(8, "Informe o WhatsApp."),
  cidade: z.string().min(2, "Informe a cidade."),
  letzplay: z.string().min(2, "Informe o nome cadastrado no LetzPlay."),
  federacao: z.string().optional().or(z.literal("")),
});

export const TeamSchema = z.object({
  categoria: z.string().min(1),
  atleta1: AthleteSchema,
  atleta2: AthleteSchema,
});

export type TeamPayload = z.infer<typeof TeamSchema>;
