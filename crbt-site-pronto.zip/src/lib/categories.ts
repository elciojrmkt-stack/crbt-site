export type CategorySlug =
  | "masc-bc"
  | "masc-d"
  | "masc-e"
  | "fem-bc"
  | "fem-d"
  | "fem-e";

export const CATEGORIES: { slug: CategorySlug; label: string }[] = [
  { slug: "masc-bc", label: "Masculino B+C" },
  { slug: "masc-d", label: "Masculino D" },
  { slug: "masc-e", label: "Masculino E" },
  { slug: "fem-bc", label: "Feminino B+C" },
  { slug: "fem-d", label: "Feminino D" },
  { slug: "fem-e", label: "Feminino E" },
];

export const LIMIT_PER_CATEGORY = 16;
export const PRICE_PER_ATHLETE = 100;
export const PRICE_PER_TEAM = 200;
