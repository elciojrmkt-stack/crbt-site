import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "CRBT – Inscrições",
  description: "Inscrições CRBT – Circuito Regional de Beach Tennis",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body style={{ margin: 0, fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif", background: "#0a1322", color: "#0b0b0b" }}>
        <div style={{ minHeight: "100vh", background: "linear-gradient(180deg,#0a1322 0%, #0b1f3a 35%, #06101f 100%)", padding: 18 }}>
          <div style={{ maxWidth: 980, margin: "0 auto" }}>
            <div style={{ borderRadius: 18, overflow: "hidden", background: "white" }}>
              {children}
            </div>
            <footer style={{ color: "rgba(255,255,255,.8)", fontSize: 12, padding: "12px 4px" }}>
              CRBT • Pagamento via Mercado Pago • Suporte: chame no direct
            </footer>
          </div>
        </div>
      </body>
    </html>
  );
}
