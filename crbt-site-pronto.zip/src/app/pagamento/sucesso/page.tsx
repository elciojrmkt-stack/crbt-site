export default function Page() {
  return (
    <main style={ padding: 24 }>
      <h1 style={ marginTop: 0 }>Pagamento aprovado ✅</h1>
      <p>Sua inscrição foi confirmada. Em breve você receberá uma mensagem no WhatsApp.</p>
      <a href="/" style={ fontWeight: 800, color: "#0b1f3a", textDecoration: "none" }>Voltar ao início</a>
    </main>
  );
}
