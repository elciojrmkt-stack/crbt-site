export default function Page() {
  return (
    <main style={ padding: 24 }>
      <h1 style={ marginTop: 0 }>Pagamento não concluído ❌</h1>
      <p>Não conseguimos confirmar o pagamento. Tente novamente ou chame no direct.</p>
      <a href="/" style={ fontWeight: 800, color: "#0b1f3a", textDecoration: "none" }>Voltar ao início</a>
    </main>
  );
}
