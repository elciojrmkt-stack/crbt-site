export default function Page() {
  return (
    <main style={ padding: 24 }>
      <h1 style={ marginTop: 0 }>Pagamento pendente ⏳</h1>
      <p>Seu pagamento está em análise. Assim que aprovar, a inscrição será confirmada automaticamente.</p>
      <a href="/" style={ fontWeight: 800, color: "#0b1f3a", textDecoration: "none" }>Voltar ao início</a>
    </main>
  );
}
