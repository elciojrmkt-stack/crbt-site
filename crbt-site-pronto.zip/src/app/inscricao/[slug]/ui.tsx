"use client";

import { useState } from "react";
import { PRICE_PER_TEAM } from "@/lib/categories";

export default function CheckoutForm({
  categorySlug,
  categoryLabel,
}: {
  categorySlug: string;
  categoryLabel: string;
}) {
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setErr(null);
    setLoading(true);

    const fd = new FormData(e.currentTarget);
    const payload = {
      categoria: categorySlug,
      atleta1: {
        nome: String(fd.get("a1_nome") || ""),
        whatsapp: String(fd.get("a1_whats") || ""),
        cidade: String(fd.get("a1_cidade") || ""),
        letzplay: String(fd.get("a1_letz") || ""),
        federacao: String(fd.get("a1_fed") || ""),
      },
      atleta2: {
        nome: String(fd.get("a2_nome") || ""),
        whatsapp: String(fd.get("a2_whats") || ""),
        cidade: String(fd.get("a2_cidade") || ""),
        letzplay: String(fd.get("a2_letz") || ""),
        federacao: String(fd.get("a2_fed") || ""),
      },
    };

    const res = await fetch("/api/checkout/create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ payload, categoryLabel }),
    });

    const json = await res.json().catch(() => ({}));
    if (!res.ok) {
      setErr((json as any)?.error || "Erro ao iniciar pagamento.");
      setLoading(false);
      return;
    }

    window.location.href = (json as any).init_point;
  }

  return (
    <form onSubmit={submit} style={{ display: "grid", gap: 12 }}>
      <div style={card}>
        <h3 style={h3}>Atleta 1</h3>
        <input name="a1_nome" placeholder="Nome completo" required style={inp} />
        <input name="a1_whats" placeholder="WhatsApp (com DDD)" required style={inp} />
        <input name="a1_cidade" placeholder="Cidade" required style={inp} />
        <input name="a1_letz" placeholder="Nome no LetzPlay (obrigatório)" required style={inp} />
        <input name="a1_fed" placeholder="Código da federação (opcional)" style={inp} />
      </div>

      <div style={card}>
        <h3 style={h3}>Atleta 2</h3>
        <input name="a2_nome" placeholder="Nome completo" required style={inp} />
        <input name="a2_whats" placeholder="WhatsApp (com DDD)" required style={inp} />
        <input name="a2_cidade" placeholder="Cidade" required style={inp} />
        <input name="a2_letz" placeholder="Nome no LetzPlay (obrigatório)" required style={inp} />
        <input name="a2_fed" placeholder="Código da federação (opcional)" style={inp} />
      </div>

      <div style={{ ...card, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ fontWeight: 800 }}>Categoria</div>
          <div style={{ opacity: 0.8 }}>{categoryLabel}</div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontWeight: 800 }}>Total</div>
          <div style={{ fontSize: 18, fontWeight: 900, color: "#0b1f3a" }}>R$ {PRICE_PER_TEAM},00</div>
        </div>
      </div>

      {err && <div style={errBox}>{err}</div>}

      <button type="submit" disabled={loading} style={btn}>
        {loading ? "Aguarde..." : "Pagar e confirmar inscrição"}
      </button>
    </form>
  );
}

const card: React.CSSProperties = {
  padding: 14,
  border: "1px solid #e9e9e9",
  borderRadius: 16,
  boxShadow: "0 10px 22px rgba(0,0,0,.06)",
};
const h3: React.CSSProperties = { marginTop: 0, marginBottom: 10 };
const inp: React.CSSProperties = {
  width: "100%",
  padding: "12px 12px",
  borderRadius: 12,
  border: "1px solid #ddd",
  marginTop: 8,
};
const btn: React.CSSProperties = {
  padding: "14px 16px",
  borderRadius: 16,
  border: 0,
  background: "#0b1f3a",
  color: "white",
  fontWeight: 900,
  cursor: "pointer",
  boxShadow: "0 14px 26px rgba(11,31,58,.25)",
};
const errBox: React.CSSProperties = {
  padding: 12,
  borderRadius: 12,
  border: "1px solid #ffb3b3",
  background: "#ffecec",
  fontWeight: 700,
};
