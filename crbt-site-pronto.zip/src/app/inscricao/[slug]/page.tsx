import { CATEGORIES, PRICE_PER_TEAM, LIMIT_PER_CATEGORY } from "@/lib/categories";
import { sheetsCountApprovedByCategory } from "@/lib/sheets";
import CheckoutForm from "./ui";

export default async function CategoryPage({ params }: { params: { slug: string } }) {
  const cat = CATEGORIES.find((c) => c.slug === params.slug);
  if (!cat) return <div style={{ padding: 24 }}>Categoria não encontrada.</div>;

  const approved = await sheetsCountApprovedByCategory(cat.slug);
  const remaining = Math.max(0, LIMIT_PER_CATEGORY - approved);
  const soldOut = remaining === 0;

  return (
    <main style={{ padding: 24 }}>
      <a href="/" style={{ textDecoration: "none", color: "#0b1f3a", fontWeight: 800 }}>← Voltar</a>
      <h1 style={{ marginBottom: 6 }}>{cat.label}</h1>
      <p style={{ marginTop: 0, opacity: 0.85 }}>
        Valor: <strong>R$ {PRICE_PER_TEAM},00</strong> por dupla • Vagas restantes: <strong>{remaining}</strong>
      </p>

      {soldOut ? (
        <div style={{ padding: 16, borderRadius: 14, border: "1px solid #ffcc00", background: "#fff8db" }}>
          <strong>Categoria lotada.</strong> Entre em contato via direct para lista de espera.
        </div>
      ) : (
        <CheckoutForm categorySlug={cat.slug} categoryLabel={cat.label} />
      )}

      <div style={{ marginTop: 14, fontSize: 12, opacity: 0.7 }}>
        * A inscrição é confirmada após aprovação do pagamento.
      </div>
    </main>
  );
}
