import Image from "next/image";
import Link from "next/link";
import { CATEGORIES } from "@/lib/categories";

export default function Home() {
  return (
    <main style={{ padding: 24 }}>
      <header style={{ display: "flex", alignItems: "center", gap: 16 }}>
        <Image src="/crbt-logo.jpg" alt="CRBT" width={110} height={110} style={{ borderRadius: 14 }} />
        <div>
          <h1 style={{ margin: 0, fontSize: 26 }}>CRBT – Circuito Regional de Beach Tennis</h1>
          <p style={{ marginTop: 10, marginBottom: 0, lineHeight: 1.35 }}>
            <strong>Início da fase de grupos:</strong> 23 de fevereiro<br />
            <strong>Finais:</strong> Arena Yellow – Apucarana
          </p>
        </div>
      </header>

      <section style={{ marginTop: 22 }}>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          <div style={pill}>R$100 por atleta (R$200 por dupla)</div>
          <div style={pill}>16 duplas por categoria</div>
          <div style={pill}>Pagamento imediato (Pix/Cartão)</div>
          <div style={pill}>LetzPlay obrigatório</div>
        </div>
      </section>

      <section style={{ marginTop: 22 }}>
        <h2 style={{ marginBottom: 10 }}>Escolha a categoria</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 12 }}>
          {CATEGORIES.map((c) => (
            <Link
              key={c.slug}
              href={`/inscricao/${c.slug}`}
              style={{
                border: "1px solid #e6e6e6",
                borderRadius: 16,
                padding: 16,
                textDecoration: "none",
                color: "inherit",
                boxShadow: "0 8px 18px rgba(0,0,0,.06)",
              }}
            >
              <div style={{ fontSize: 18, fontWeight: 800 }}>{c.label}</div>
              <div style={{ opacity: 0.75, marginTop: 6 }}>Inscrição por dupla</div>
              <div style={{ marginTop: 10, fontWeight: 800, color: "#0b1f3a" }}>Inscrever agora →</div>
            </Link>
          ))}
        </div>
      </section>

      <section style={{ marginTop: 18, fontSize: 13, opacity: 0.8 }}>
        Dúvidas? Chame no direct do CRBT.
      </section>
    </main>
  );
}

const pill: React.CSSProperties = {
  background: "#0b1f3a",
  color: "white",
  padding: "8px 12px",
  borderRadius: 999,
  fontSize: 13,
  fontWeight: 700,
};
