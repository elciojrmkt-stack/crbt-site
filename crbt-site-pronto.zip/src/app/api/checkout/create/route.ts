import { NextResponse } from "next/server";
import { TeamSchema } from "@/lib/validation";
import { PRICE_PER_TEAM } from "@/lib/categories";
import { sheetsCreatePending } from "@/lib/sheets";
import crypto from "crypto";
import { MercadoPagoConfig, Preference } from "mercadopago";

const accessToken = process.env.MP_ACCESS_TOKEN;
if (!accessToken) {
  // Fail fast in runtime if env missing
  console.warn("MP_ACCESS_TOKEN não configurado");
}

const client = new MercadoPagoConfig({
  accessToken: accessToken || "",
});

export async function POST(req: Request) {
  try {
    const { payload, categoryLabel } = await req.json();
    const parsed = TeamSchema.parse(payload);

    const externalReference = `CRBT-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`;

    await sheetsCreatePending({
      category: parsed.categoria,
      payload: parsed,
      externalReference,
    });

    const baseUrl = process.env.BASE_URL || "http://localhost:3000";

    const preference = new Preference(client);
    const pref = await preference.create({
      body: {
        external_reference: externalReference,
        items: [
          {
            id: parsed.categoria,
            title: `CRBT 2026 - ${categoryLabel} (Dupla)`,
            quantity: 1,
            unit_price: PRICE_PER_TEAM,
            currency_id: "BRL",
          },
        ],
        back_urls: {
          success: `${baseUrl}/pagamento/sucesso`,
          pending: `${baseUrl}/pagamento/pendente`,
          failure: `${baseUrl}/pagamento/erro`,
        },
        auto_return: "approved",
        notification_url: `${baseUrl}/api/mercadopago/webhook`,
        metadata: {
          categoria: parsed.categoria,
          total: PRICE_PER_TEAM,
        },
      },
    });

    return NextResponse.json({ init_point: pref.init_point });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Erro" }, { status: 400 });
  }
}
