import { NextResponse } from "next/server";
import { MercadoPagoConfig, Payment } from "mercadopago";
import { sheetsUpdateStatus } from "@/lib/sheets";

const client = new MercadoPagoConfig({
  accessToken: process.env.MP_ACCESS_TOKEN || "",
});

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const paymentId = (body as any)?.data?.id || (body as any)?.id;

    if (!paymentId) return NextResponse.json({ ok: true });

    const payment = new Payment(client);
    const pay: any = await payment.get({ id: String(paymentId) });

    const externalReference = String(pay?.external_reference || "");
    const status = String(pay?.status || "pending");

    if (externalReference) {
      await sheetsUpdateStatus({
        externalReference,
        status: status as any,
        paymentId: String(paymentId),
      });
    }

    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ ok: true });
  }
}
